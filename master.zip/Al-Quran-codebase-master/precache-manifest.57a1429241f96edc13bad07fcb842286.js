self.__precacheManifest = [
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/Quran-Codebase/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "49c61ec283e46d8e87df",
    "url": "/Quran-Codebase/static/js/runtime~main.89f054b6.js"
  },
  {
    "revision": "1f837a845882b5ef3db8",
    "url": "/Quran-Codebase/static/js/main.04f9a179.chunk.js"
  },
  {
    "revision": "f4f24bf31782adf3426c",
    "url": "/Quran-Codebase/static/js/2.d808b26a.chunk.js"
  },
  {
    "revision": "1f837a845882b5ef3db8",
    "url": "/Quran-Codebase/static/css/main.c012efd1.chunk.css"
  },
  {
    "revision": "f0e329a2a7275131909ece51430fe418",
    "url": "/Quran-Codebase/index.html"
  }
];